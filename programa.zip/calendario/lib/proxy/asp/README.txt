.NET proxy version 
written by Alessandro Benedetti

You need the open source Newtonsoft.Json to compile.