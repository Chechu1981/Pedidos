<?php
/*$meses = array ("enero","febrero","marzo","abril","mayo","junio","julio","agosto","sepriembre","octubre","noviembre","diciembre");
?><div id="Date"><?php echo date('d')." de ".$meses[date('m')-1]." de ".date('Y');?></div>*/
?><div><?php echo date('H')." : ".date('i')." : ".date('s'); ?></div>