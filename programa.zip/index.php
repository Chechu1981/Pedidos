<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//ES" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd" >
<html>
    <head>
        <meta content="text/html; charset=iso-8859-1" http-equiv="content-type"/>
        <title>Carri�n</title>
        <link rel="shortcut icon" href="./imagenes/chechu.ico" />
		<style>
		html, body, div, iframe{
                    margin:0; 
                    padding:0; 
                    height:100%; 
                }
		iframe{ 
                    display:block; 
                    width:100%; 
                    border:none; 
                }
		</style>
    </head>
    <body>
        <iframe src="indice.php" ></iframe>
    </body>
</html>