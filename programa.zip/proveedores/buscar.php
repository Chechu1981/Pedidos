
<table class="listbuscar">
    <th>Fecha recibido</th><th>Fecha de pedido</th><th>Proveedor</th><th>Operario</th><th>Orden</th><th>Comentario</th><th>Pedido</th><th>Recepcionado</th>
<?php
header("Cache-Control: no-store, no-cache, must-revalidate");
include ('../estilos/conexion.php');
//if(isset($_GET['oper']) and isset($_GET['ord']) and isset($_GET['prove']))
$result=mysql_query("SELECT * FROM o_proveedores  WHERE proveedor LIKE '%".$_GET['prove']."%'AND operario LIKE '%".$_GET['oper']."%' AND orden LIKE '%".$_GET['ord']."%' ORDER BY fecha_recibido DESC;");
while($lineas=mysql_fetch_row($result)){;
    ?> <tr> <?php
    for($i=1;$i<9;$i++){
        ?> <td> <?php        
            echo utf8_encode($lineas[$i]);
        ?> </td> <?php } ?>
    <tr/> <?php } ?>
</table>