<table border="1" class="volvo">
    <th>Recibido</th><th>Fecha de pedido</th><th>Proveedor</th><th>Operario</th><th>Orden</th><th>Comentario</th><th>Pedido</th><th>Recepcionado</th>
<?php
header("Cache-Control: no-store, no-cache, must-revalidate");
include ('../estilos/conexion.php');
$result= mysql_query("SELECT * FROM o_proveedores WHERE fecha_recibido NOT LIKE '%000%' ORDER BY fecha_recibido DESC;");
while($lineas=mysql_fetch_row($result)){;
    ?> <tr> <?php
    for($i=1;$i<9;$i++){
        ?> <td> <?php        
            echo utf8_encode($lineas[$i]);
        ?> </td> <?php } ?>
    <tr/> <?php } ?>
</table>