<table border="1" class="listado">
    <th>Fecha de pedido</th><th>Proveedor</th><th>Operario</th><th>Orden</th><th>Comentario</th><th>Pedido</th><th>Recibido</th><th></th>
<?php
header("Cache-Control: no-store, no-cache, must-revalidate");
include ('../estilos/conexion.php');
$result= mysql_query("SELECT * FROM o_proveedores WHERE fecha_recibido LIKE '%0000%' ORDER BY fecha_pedido DESC;");
while($lineas=mysql_fetch_row($result)){;
    ?> <tr> <?php
    for($i=2;$i<8;$i++){
        ?> <td> <?php
        if($i==6){
            ?><div><textarea name="comenatrio" id="com<?php echo utf8_encode($lineas[0]) ?>" onclick="editar()" onblur="actualizar(<?php echo utf8_encode($lineas[0]) ?>);enviar()"><?php echo utf8_encode($lineas[$i]) ?></textarea></div><?php
        }else{        
            echo utf8_encode($lineas[$i]);
        }
        ?> </td> <?php }
        ?><td><div type="button" value="Recibido" class="recibido" onclick="recibido('<?php echo utf8_encode($lineas[0]); ?>','<?php echo utf8_encode($lineas[3]) ?>')">Recibido</div></td>
        <td><img src="../imagenes/eliminar.png" title="Elimiar" style="cursor: pointer" onclick="confirmar_linea('<?php echo utf8_encode($lineas[0]); ?>','<?php echo utf8_encode($lineas[3]) ?>')"/></td>
    <tr/> <?php
}
?>
</table>