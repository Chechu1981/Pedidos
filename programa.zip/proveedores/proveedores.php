<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
 "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html;" charset="ISO-8859-1" />
        <title>Otros proveedores</title>
        <link rel="shortcut icon" href="../imagenes/chechu.ico" />
        <link rel="stylesheet" type="text/css" href="../estilos/style.css" />
        <link type="text/css" href="../scripts/jquery-ui-1.8.21.custom/css/redmond/jquery-ui-1.8.24.custom.css" rel="stylesheet" />
        <script src="../scripts/jquery-ui-1.8.21.custom/js/jquery-1.7.2.min.js"></script>
        <script src="../scripts/jquery-ui-1.8.21.custom/js/jquery-ui-1.8.21.custom.min.js"></script>
        <script>
        function objetoAjax(){
            var xmlhttp=false;
            try {
		xmlhttp = new ActiveXObject("Msxml2.XMLHTTP");
            } catch (e) {
            try {
               xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
            } catch (E) {
            	xmlhttp = false;
            }
		}
			if (!xmlhttp && typeof XMLHttpRequest!='undefined') {
			xmlhttp = new XMLHttpRequest();
		}
			return xmlhttp;
		}
             var ajax=objetoAjax();
             var actual=objetoAjax();
             var elim=objetoAjax();
             var anti=objetoAjax();
        function enviar(){
                var h2=document.getElementById('titulo');
                h2.innerHTML="En curso</br><img src='../imagenes/29.gif' />";
                ajax.open('GET','tabla.php',true);
                ajax.send(null);
                ajax.onreadystatechange = respuesta;
        }
        function respuesta(){
                var div=document.getElementById('tabla');
                if(ajax.readyState==4){
                        div.innerHTML = ajax.responseText;	
                }else{
                        div.value = "";
                }
        }
        function actualizar(id){
            var com=document.getElementById('com'+id).value;
            actual.open('GET','actualizar.php?com='+com+'&id='+id,true);
            actual.send(null);
            ajax.onreadystatechange = respuesta;
        }
        function eliminar(id){
            elim.open('GET','eliminar.php?id='+id);
            elim.send(null);
            elim.onreadystatechange = respuesta;
        }
        function nuevo(){
            $(function() {
                //$( "#dialog:ui-dialog" ).dialog( "destroy" );
                $( "#new" ).dialog({
                    height: 550,
                    width: 1000,
                    modal: true,
                    show: "fold",
                    hide: "scale",
                    title: 'Otros proveedores'
                    });
                 });
        }
        function closeIframe()
            {
                enviar();
                $("#new").dialog('destroy');
                return false;
            }
        function confirmar_linea (id,proveedor){
            $respuesta=confirm("�Quieres eliminar el pedido de "+proveedor+"?");
            if($respuesta){
                eliminar(id);
                alert("Pedido de "+proveedor+" eliminado.");
                enviar();
            }
        }
        function recibido(id,proveedor){
            $respuesta=confirm("El pedido de "+proveedor+" ha sido recibido.");
            if($respuesta){
                recepcion(id);
            }
        }
        function antigu(){
            anti.open('GET','antiguos.php',true);
            anti.send(null);
            anti.onreadystatechange = resanti;
        }
        function resanti(){
            var div=document.getElementById('tabla');
            var h2=document.getElementById('titulo');
            if(anti.readyState==4){
                    div.innerHTML = anti.responseText;
                    h2.innerHTML = "Antiguos";
            }else{
                    div.value = "";
            }
	}
        var busc=new objetoAjax();
        function buscar(){
            var prov=document.getElementById('prove').value;
            var ord=document.getElementById('ord').value;
            var operario=document.getElementById('oper').value;
            busc.open('GET','buscar.php?prove='+prov+'&ord='+ord+'&oper='+operario,true);
            busc.send(null);
            busc.onreadystatechange = encontrar;
        }
        function encontrar(){
            var div=document.getElementById('tabla');
            var h2=document.getElementById('titulo');
            if(busc.readyState==4){
                    div.innerHTML = busc.responseText;
                    h2.innerHTML = "Buscar";
		}else{
                    div.value = "";
		}
        }
        function examinar(){
            setInterval(function(){
                if(document.getElementById('titulo').innerHTML == 'En curso')
                   enviar();
            },1000);
        }
        function comentario(){
            $(function() {
                //$( "#dialog:ui-dialog" ).dialog( "destroy" );
                $( "#comentario" ).dialog({
                    height: 300,
                    width: 300,
                    modal: true,
                    show: "fold",
                    hide: "scale",
                    title: 'Modificar comentario'
                    });
                 });
        }
        function editar(){
            var h2=document.getElementById('titulo');
            h2.innerHTML = "Editar";
        }
        function recepcion(id){
            $(function() {        
                $( "#dialog-message" ).dialog({            
                    modal: true,            
                    buttons: {                
                        Aceptar: function() {                    
                            $( this ).dialog( "close" ); 
                            var oper=document.getElementById('nomb').value;
                            actual.open('GET','recibido.php?id='+id+'&oper='+oper,true);
                            actual.send(null);
                            enviar();
                        }            
                    }        
                });    
            });
        }
	</script>
    </head>
    <body onload="enviar();examinar()" >
        <div id="dialog-message" style="display: none" title="Nombre del operario">       
                <span class="ui-icon ui-icon-circle-check" style="float: left; margin: 0 7px 50px 0;">
                </span>        
            Nombre:
            <p>        
                <input id="nomb"></input>    
            </p>
        </div>
        <div class="buscar" style="width: 170px;position: fixed;margin-top:120px">
            <fieldset title="Buscar"><legend>Buscar</legend>
                <table>
                    <tr>
                        <td>Proveedor</td><td><input size="10" onkeyup="buscar()" type="text" id="prove" name="proveedor" value=""></input></td>
                    </tr>
                    <tr>
                        <td>Orden</td><td><input size="10" onkeyup="buscar()" type="text" id="ord" name="orden" value=""></input></td>
                    </tr>
                    <tr>
                        <td>Operario</td><td><input size="10" onkeyup="buscar()" type="text" id="oper" name="opeario" value=""></input></td>
                    </tr>
                </table>            
            </fieldset>
        </div>
        <div id="new" style="display:none"><iframe style="padding: 20px" src="nuevo.php" height="400" width="900"></iframe></div>
        <?php 
        $saludo=  getdate(time());
         if($_SERVER['REMOTE_USER']=="medina"){
            if($saludo['hours']<12){
            echo "<span class=\"saludo\" >Buenos d�as Medina del Campo</span>";
             }else{
             echo "<span class=\"saludo\" >Buenas tardes Medina del Campo</span>";
             }
        }else if($_SERVER['REMOTE_USER']=="recepcion"){
            if($saludo['hours']<12){
            echo "<span class=\"saludo\" >Buenos d�as recepci�n</span>";
            }else{
                echo "<span class=\"saludo\" >Buenas tardes recepci�n</span>";
            }
        }else{
            if($saludo['hours']<12){
            echo "<span class=\"saludo\" >Buenos d�as Valladolid</span>";
            }else{
                echo "<span class=\"saludo\" >Buenas tardes Valladolid</span>";
            }
        }
        if((date('j')>=25 and date('n')==12)or(date('j')<=6 and date('n')==1)){?>
            <img style=" margin: 10px;margin-top: 45px;left: 10px;position:fixed;" src="../imagenes/navidad.jpg" width="150px" />
        <?php }else{ ?>
            <img style=" margin: 10px; margin-top: 45px;left: 10px;position:fixed;" src="../imagenes/carrion.jpg" width="150px" />
        <?php } ?>
        <div class="contenedor">
            <?php if($_SERVER['REMOTE_USER']=="medina"){ ?>
<div id="c_ed6da3b0c2c5b38d1ae9a2fbb92eec48" class="ancho"></div><script type="text/javascript" src="http://www.eltiempo.es/widget/widget_loader/ed6da3b0c2c5b38d1ae9a2fbb92eec48"></script>
<?php }else{ ?>
        <div id="c_e57fa2f6fac3f87fd870f0eebef7dbcc" class="ancho">
        	<h2 style="color: #000000; margin: 0 0 3px; padding: 2px; font: bold 13px/1.2 Verdana; text-align: center;"></h2>
            </div>
			<script type="text/javascript" src="http://www.eltiempo.es/widget/widget_loader/e57fa2f6fac3f87fd870f0eebef7dbcc">
            </script>
<?php } include '../calendario/calcular_dia.php'; ?>
        	<div class="principal">
            <ul>
                <a href="../index.php" target="_self"><li>Inicio</li></a>
                <a href="../clientes/clientes.php" target="_self"><li>Clientes</li></a>
                <a href="../cruze/cruze.php" target="_self"><li>Referencias cruzadas</li></a>
                <a href="../enlaces/enlaces.php" target="_self"><li>Enlaces</li></a>
                <a href="../cambio/cambio.php"><li>Cambio</li></a>
                <a href="../calendario/pedidos.php?numes=<?php echo calcular_numes(); ?>&dia=<?php echo calcular_dia(); ?>&mes=<?php echo calcular_mes(); ?>&ano=<?php echo calcular_ano();?>"><li>Pedidos Citroen</li></a>
		<?php if($_SERVER['REMOTE_USER']!="medina"){ ?><a href="../pedidosv/pedidosv.php?numes=<?php echo calcular_numesv(); ?>&dia=<?php echo calcular_diav(); ?>&mes=<?php echo calcular_mesv(); ?>&ano=<?php echo calcular_anov();?>"><li>Pedidos Volvo</li></a>
                <a href="proveedores.php" ><li id="activo">Otros proveedores</li></a> <?php } ?>
            </ul>
            <div class="banda">
                <h2 style="padding:15px;" id="titulo">Otros proveedores</h2>
                <div id="nuevo" onclick="nuevo()">
                    Nuevo pedido
                </div>
                <div class="antig" onclick="antigu()">
                    Antiguos
                </div>
                <div class="antig" onclick="enviar()">
                    En curso
                </div>
                
            </div>
                    <div style="clear: both"></div>
                    <div id="tabla"></div>
             </div>
                    
            <div class="pie">
            <hr/>
            Empresa Carri�n SA <span>Jes�s Mart�n 2012 �</span>
            </div>
    </div>
    </body>
</html>