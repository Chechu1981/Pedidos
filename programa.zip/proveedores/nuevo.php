<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
 "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
    <head>
        <meta http-equiv=Content-Type content="text/html; charset=ISO-8859-1"></meta>
        <title>Crear contacto</title>
        <link rel="shortcut icon" href="favicon.ico" ></link>
        <link rel="stylesheet" type="text/css" href="../estilos/style.css"></link>
        <link href="http://ajax.googleapis.com/ajax/libs/jqueryui/1.8/themes/base/jquery-ui.css" rel="stylesheet" type="text/css"/>
        <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.5/jquery.min.js"></script>
        <script src="http://ajax.googleapis.com/ajax/libs/jqueryui/1.8/jquery-ui.min.js"></script>
    </head>
    <body>
        <?php
        header("Cache-Control: no-store, no-cache, must-revalidate");
       	include ('../estilos/conexion.php');
        function saltoLinea($str){
            return str_replace(array("\r\n", "\r", "\n"), "<br />", $str);
        }
        ?>
        <div class="contenedor">
            <h1>Nuevo pedido </h1>
        <div id="formulario">
            <form method="POST" action="nuevo.php" name="nuevo" class="formularioprov">
                            <table>
                                <th>Proveedor</th>
                                <th>Operario</th>
                                <th>Orden</th>
                                <th>Comentario</th>
                                <tr>
                                    <td><input type="text" id="prov" name="proveedor" value="<?php if(isset($_POST['proveedor'])) echo $_POST['proveedor'] ?>"></input></td>
                                    <td><input type="text" name="operario" value="<?php if(isset($_POST['operario'])) echo $_POST['operario'] ?>"></input></td>
                                    <td><input type="text" name="orden" value="<?php if(isset($_POST['orden'])) echo $_POST['orden'] ?>"></input></td>
                                    <td><input type="text" name="comentario" value="<?php if(isset($_POST['comentario'])) echo $_POST['comentario'] ?>"></input></td>
                                </tr>
                                <tr><td colspan="4"><textarea style="background-color: antiquewhite" rows="10" cols="100" name="pedido" value="<?php if(isset($_POST['pedido'])) echo $_POST['pedido'] ?>"><?php if(isset($_POST['pedido'])) echo $_POST['pedido'] ?></textarea></td></tr>
                                <tr><td colspan="4" align="center"><input type="submit" name="new" title="Guardar pedido" value="Guardar pedido" class="recibido_btn" style="height: 50px;font-weight: bold"></input></td></tr>
                            </table>
                        </form>
                    </div>
            <?php
            if(isset($_POST['new'])){
                        if($_POST['proveedor']==''){
                            ?> <script language="javascript"> alert("El nombre del proveedor no puede estar vac�o");</script><?php
                        }else{
                        $texto = $_POST['pedido'];
                        mysql_query("INSERT INTO o_proveedores VALUES('','',NOW(),'".strtoupper($_POST['proveedor'])."','".strtoupper($_POST['operario'])."','".strtoupper($_POST['orden'])."','".strtoupper($_POST['comentario'])."','".strtoupper(saltoLinea($texto))."','');");
                        ?> <script language="javascript"> 
                            //alert("Pedido de <?php $_POST['proveedor'] ?> creado con �xito."); 
                            window.parent.closeIframe();</script>'; <?php
                }
            }
            ?>
        <div class="pie">
            <hr>
           Empresa Carri�n SA <span>Jes�s Mart�n 2012 �</span>
        </div>
        </div>
    </body>
</html>