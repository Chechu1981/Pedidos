<?php
	mysql_connect("localhost","chechu");
	mysql_select_db("carrion");
?>